﻿open Vector
 
[<EntryPoint>]
let main argv =
   let v1 = make (3.0,2.0)
   let v2 = make (1.0,-1.0)
   let _ = printfn "v1=%s v2=%s" (string v1) (string v2)
   printfn "v1+v2=%s" (string (v1+v2)) 
   printfn "v1*v2=%s" (string (v1*v2))
   0 // return an integer exit code
   
