module Vector

[<Sealed>]
type Vector =
 static member (+) : Vector * Vector -> Vector
 static member (*) : Vector * Vector -> double
 static member (*) : double * Vector -> Vector
val coord : Vector -> double * double
val norm : Vector -> double
val make : double * double -> Vector
