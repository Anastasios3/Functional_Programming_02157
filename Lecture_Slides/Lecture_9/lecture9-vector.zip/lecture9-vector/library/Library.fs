﻿module Vector

type Vector =
 | V of (double*double)
 override p.ToString() = match p with V (a1,a2) -> "("+(string a1)+","+(string a2)+")"
 static member (+) (V (a1,a2),V (b1,b2)) = V(a1+b1,a2+b2)
 static member (*) (V (a1,a2),V (b1,b2)) = a1*b1+a2*b2 
 static member (*) (c,(V (a1,a2))) = V (c*a1,c*a2) 
let coord (V (a1,a2)) = (a1,a2)
let norm (v:Vector) = sqrt (v*v)
let make (a1,a2) = V (a1,a2)
